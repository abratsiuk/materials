import about from './about';
import './styles/index.scss';

console.log('Hello from Webpack');

console.log('hi again');
about();
