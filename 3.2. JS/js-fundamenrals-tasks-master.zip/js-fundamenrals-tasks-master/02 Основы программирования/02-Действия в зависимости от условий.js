const x = 10;
let isOdd;

// Напишите ваш код далее
if (x % 2 === 0) {
    isOdd = false;
} else {
    isOdd = true;
}