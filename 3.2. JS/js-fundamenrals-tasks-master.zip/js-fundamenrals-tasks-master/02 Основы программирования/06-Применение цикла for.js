const numbers = [1, 2, 3, 4, 5, 6];

for (let i = 0; i < numbers.length; i += 2) {
    numbers[i] += 3;
}