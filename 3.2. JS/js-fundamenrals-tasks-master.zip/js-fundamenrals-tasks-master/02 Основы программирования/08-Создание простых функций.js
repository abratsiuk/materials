function multiply(a, b, c) {
    return a * b * c;
}

function euroToRub(num) {
    return num * 90;
}

function milesToKm(distance) {
    return distance * 1.609;
}