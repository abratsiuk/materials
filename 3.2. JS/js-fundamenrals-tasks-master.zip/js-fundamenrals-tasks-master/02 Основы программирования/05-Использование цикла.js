const numbers = [2, 7, 19, 22, 38, 9];

let index = 1;

while (index < numbers.length) {
    numbers[index] *= 2;
    index += 2;
}