function addByX(x) {
    return (num) => x + num;
  }