const square = x => x * x;

const multiply = (a, b) => a * b;

const checkAge = age => {
    if (age >= 18) {
        console.log('welcome');
    } else {
        console.log('access denied');
    }
};
