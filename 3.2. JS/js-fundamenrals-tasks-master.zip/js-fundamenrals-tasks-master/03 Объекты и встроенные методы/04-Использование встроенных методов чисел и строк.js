// 1.
const correctAnswer = 'JavaScript';
const userAnswer = ' javaScript! ';
const isCorrect = userAnswer.toLowerCase().includes(correctAnswer.toLowerCase());

// 2.
const salary = 15000.2085;
const salaryFixed = salary.toFixed(2);