const htmlDiv = {
    className: 'column',
    rel: 'main',
    id: 'block',
};

for (let prop in htmlDiv) {
    console.log(htmlDiv[prop]);
}