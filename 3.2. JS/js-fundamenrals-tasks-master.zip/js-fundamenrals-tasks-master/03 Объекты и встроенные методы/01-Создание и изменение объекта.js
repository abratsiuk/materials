const dog = {
    name: 'Sanek',
    age: 1,
    color: 'white',
    weight: 5,
};

dog.breed = 'shepherd';