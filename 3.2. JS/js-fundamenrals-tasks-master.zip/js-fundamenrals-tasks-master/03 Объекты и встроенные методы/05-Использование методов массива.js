// 1
const fruits = ['apple', 'banana', 'melon', 'orange'];
const hasOrange = fruits.includes('orange');

// 2
const cars = ['BMW', 'Nissan', 'VW', 'Skoda', 'Audi', 'Kia'];
const favoriteCars = cars.slice(0, 3);
const otherCars = cars.slice(3);