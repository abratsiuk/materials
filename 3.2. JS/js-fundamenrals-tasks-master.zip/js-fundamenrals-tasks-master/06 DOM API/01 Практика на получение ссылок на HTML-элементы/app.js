const title = document.querySelector('h1');

const btn = document.getElementsByTagName('button')[0];

const subtitle = document.querySelector('h2.gray');

const sections = document.getElementsByTagName('section');