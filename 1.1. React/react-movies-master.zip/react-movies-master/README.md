# Проект React Movies для курса React с нуля для начинающих 

Рабочую версию приложения можно посмотреть на [GitHub Pages](https://michey85.github.io/react-movies/).
