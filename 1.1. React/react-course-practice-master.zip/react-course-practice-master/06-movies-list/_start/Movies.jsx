function Movies() {
    return <div className="movies"></div>;
}

export { Movies };
