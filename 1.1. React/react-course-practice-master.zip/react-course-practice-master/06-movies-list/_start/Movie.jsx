function Movie() {
    return <div className="movie card"></div>;
}

export { Movie };
