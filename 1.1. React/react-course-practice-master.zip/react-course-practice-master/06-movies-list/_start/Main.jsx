function Main() {
    return <main className="container content"></main>;
}

export { Main };
