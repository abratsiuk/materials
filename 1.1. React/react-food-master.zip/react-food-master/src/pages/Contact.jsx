function Contact() {
    return <h1>Hello, from Contact page</h1>;
}
export { Contact };
