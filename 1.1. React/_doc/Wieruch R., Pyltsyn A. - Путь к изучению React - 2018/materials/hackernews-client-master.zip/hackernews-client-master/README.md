# The Road to Learn React - Hacker News Client

[![Build Status](https://travis-ci.org/the-road-to-learn-react/hackernews-client.svg?branch=master)](https://travis-ci.org/the-road-to-learn-react/hackernews-client) [![Slack](https://slack-the-road-to-learn-react.wieruch.com/badge.svg)](https://slack-the-road-to-learn-react.wieruch.com/) [![Greenkeeper badge](https://badges.greenkeeper.io/the-road-to-learn-react/hackernews-client.svg)](https://greenkeeper.io/)

The application you will build when you read the book to [learn React](https://www.robinwieruch.de/the-road-to-learn-react/).

Find all chapter outcomes over [here](https://github.com/the-road-to-learn-react/hackernews-client).
* [Chapter 1 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/dc46f5efde0059d88a12a52886dd77b85997f78d)
* [Chapter 2 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/387b16504cad20ecf196662959087806c59de13f)
* [Chapter 3 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/ffbcb39b125a6cde080bffb74bdb8b4bd105cf75)
* [Chapter 4 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/1ee4c812f685c752a7e333a6b886875317800883)
* [Chapter 5 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/5e7cb9b8db98d1237badb462f40b4048462b21f1)
* [Chapter 6 Outcome](https://github.com/the-road-to-learn-react/hackernews-client/tree/62c8ed57ca2b00b8e35016379d013f9ce7bc5a7c)

After reading the book, you can continue to [learn more about JavaScript](https://roadtoreact.com).
