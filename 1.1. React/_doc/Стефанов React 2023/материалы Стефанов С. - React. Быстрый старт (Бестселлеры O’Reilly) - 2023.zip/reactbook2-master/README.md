This repository contains the code for the book "React: Up and Running, second edition".

* Buy the book: http://www.amazon.com/dp/1492051462/?tag=w3clubs-20
* View/report errata: https://www.oreilly.com/catalog/errata.csp?isbn=0636920252696
* Demo of the final app: https://www.whinepad.com
* Try the "chapters" standalone examples: https://react.stoyanstefanov.com/code/
* Mailing list for updates and new chapters: https://react.stoyanstefanov.com/
