import './Body.css';

const Body = ({children}) => {
  return <div className="Body">{children}</div>;
};

export default Body;
