Demo of `whinepad2` is available at https://www.whinepad.com/
