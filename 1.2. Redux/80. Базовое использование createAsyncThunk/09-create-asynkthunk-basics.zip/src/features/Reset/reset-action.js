import {createAction} from '@reduxjs/toolkit'

export const resetToDefault = createAction('root/reset-app');