const TheHeader = () => {
  return (
    <header className='header' />
  )
}

export {TheHeader};