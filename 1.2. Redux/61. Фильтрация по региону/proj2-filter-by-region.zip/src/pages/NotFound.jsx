export const NotFound = () => {
  return <div>This page doesn't exist</div>;
};
