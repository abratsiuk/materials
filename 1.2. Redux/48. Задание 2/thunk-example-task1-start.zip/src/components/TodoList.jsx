const TodoList = () => {
  return (
    <div>
      Todos
    </div>
  )
}

export {TodoList};