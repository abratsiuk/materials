import {combineReducers} from 'redux';

import {todos} from './todos-reducer';

export const rootReducer = combineReducers({
  todos,
});